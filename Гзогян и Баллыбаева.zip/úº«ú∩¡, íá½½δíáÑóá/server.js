const express = require('express');
const cors = require('cors');
const bodyParser = require('body-parser');
const jwt = require('jsonwebtoken');

const app = express();
const PORT = 3000;
const SECRET_KEY = 'my-secret-key-123';

// Middleware
app.use(cors());
app.use(bodyParser.json());

// ==============================================
// База данных пользователей
// ==============================================
const users = [
    { 
        id: 1, 
        login: 'shopmanager', 
        password: '123', 
        role: 'shopmanager', 
        name: 'Иван Петров (Управляющий магазином)'
    },
    { 
        id: 2, 
        login: 'officemanager', 
        password: '123', 
        role: 'officemanager', 
        name: 'Петр Сидоров (Управляющий офисом)'
    },
    { 
        id: 3, 
        login: 'hr', 
        password: '123', 
        role: 'hr', 
        name: 'Елена Смирнова (HR-специалист)'
    }
];

// ==============================================
// База данных заданий
// ==============================================
let tasks = [
    { 
        id: 1, 
        title: 'Установка оборудования', 
        description: 'Установить кассовое оборудование в магазине',
        startDate: '2026-04-10', 
        endDate: '2026-04-12', 
        status: 'cancelled', 
        createdBy: 1,
        createdByName: 'Иван Петров',
        requiredRoles: ['техник'], 
        assigned: [] 
    },
    { 
        id: 2, 
        title: 'Техническая проверка', 
        description: 'Проверить работу инженерных систем',
        startDate: '2026-06-20', 
        endDate: '2026-06-27', 
        status: 'in-progress', 
        createdBy: 1,
        createdByName: 'Иван Петров',
        requiredRoles: ['электрик', 'сантехник'], 
        assigned: ['Гзорян'] 
    },
    { 
        id: 3, 
        title: 'Устранение неисправностей', 
        description: 'Починить систему вентиляции',
        startDate: '2026-05-01', 
        endDate: '2026-05-10', 
        status: 'in-progress', 
        createdBy: 2,
        createdByName: 'Петр Сидоров',
        requiredRoles: ['электрик', 'сантехник'], 
        assigned: [] 
    },
    { 
        id: 4, 
        title: 'Настройка кассы', 
        description: 'Настроить программное обеспечение',
        startDate: '2026-07-01', 
        endDate: '2026-07-05', 
        status: 'done', 
        createdBy: 2,
        createdByName: 'Петр Сидоров',
        requiredRoles: ['техник'], 
        assigned: ['Гзорян', 'Григорян'] 
    },
    { 
        id: 5, 
        title: 'Ремонт электрощитка', 
        description: 'Заменить автоматы',
        startDate: '2026-07-10', 
        endDate: '2026-07-15', 
        status: 'hr-request', 
        createdBy: 2,
        createdByName: 'Петр Сидоров',
        requiredRoles: ['монтажник', 'электрик'], 
        assigned: [],
        hrRequest: true 
    },
    { 
        id: 6, 
        title: 'Проверка счётчика', 
        description: 'Проверить показания',
        startDate: '2026-11-20', 
        endDate: '2026-11-23', 
        status: 'hr-request', 
        createdBy: 2,
        createdByName: 'Петр Сидоров',
        requiredRoles: ['электрик'], 
        assigned: [],
        hrRequest: true 
    }
];

// ==============================================
// Middleware для проверки токена
// ==============================================
function authenticateToken(req, res, next) {
    const authHeader = req.headers['authorization'];
    const token = authHeader && authHeader.split(' ')[1]; // Bearer TOKEN
    
    if (!token) {
        return res.status(401).json({ message: 'Требуется авторизация' });
    }
    
    jwt.verify(token, SECRET_KEY, (err, user) => {
        if (err) {
            return res.status(403).json({ message: 'Недействительный токен' });
        }
        req.user = user;
        next();
    });
}

// ==============================================
// РОУТЫ АВТОРИЗАЦИИ
// ==============================================

/**
 * POST /api/auth/login
 * Вход в систему
 */
app.post('/api/auth/login', (req, res) => {
    const { login, password } = req.body;
    
    console.log('Попытка входа:', login);
    
    // Ищем пользователя
    const user = users.find(u => u.login === login && u.password === password);
    
    if (!user) {
        console.log('Ошибка входа: пользователь не найден');
        return res.status(401).json({ 
            success: false,
            message: 'Неверный логин или пароль' 
        });
    }
    
    // Создаем токен
    const token = jwt.sign(
        { 
            id: user.id, 
            login: user.login, 
            role: user.role 
        }, 
        SECRET_KEY, 
        { expiresIn: '24h' }
    );
    
    // Убираем пароль из ответа
    const { password: pwd, ...userWithoutPassword } = user;
    
    console.log('Успешный вход:', user.name);
    
    res.json({
        success: true,
        token: token,
        user: userWithoutPassword
    });
});

/**
 * GET /api/auth/check
 * Проверка токена (для автоматического входа)
 */
app.get('/api/auth/check', authenticateToken, (req, res) => {
    const user = users.find(u => u.id === req.user.id);
    
    if (!user) {
        return res.status(404).json({ message: 'Пользователь не найден' });
    }
    
    const { password, ...userWithoutPassword } = user;
    
    res.json({
        success: true,
        user: userWithoutPassword
    });
});

// ==============================================
// РОУТЫ ДЛЯ РАБОТЫ С ЗАДАНИЯМИ
// ==============================================

/**
 * GET /api/tasks
 * Получить все задания (требуется токен)
 */
app.get('/api/tasks', authenticateToken, (req, res) => {
    res.json(tasks);
});

/**
 * GET /api/tasks/my
 * Получить задания текущего пользователя
 */
app.get('/api/tasks/my', authenticateToken, (req, res) => {
    const myTasks = tasks.filter(t => t.createdBy === req.user.id);
    res.json(myTasks);
});

/**
 * POST /api/tasks
 * Создать новое задание
 */
app.post('/api/tasks', authenticateToken, (req, res) => {
    const user = users.find(u => u.id === req.user.id);
    
    const newTask = {
        id: tasks.length + 1,
        ...req.body,
        createdBy: req.user.id,
        createdByName: user.name,
        status: req.body.status || 'draft',
        assigned: []
    };
    
    tasks.push(newTask);
    res.status(201).json(newTask);
});

/**
 * PATCH /api/tasks/:id
 * Обновить задание
 */
app.patch('/api/tasks/:id', authenticateToken, (req, res) => {
    const taskId = parseInt(req.params.id);
    const taskIndex = tasks.findIndex(t => t.id === taskId);
    
    if (taskIndex === -1) {
        return res.status(404).json({ message: 'Задание не найдено' });
    }
    
    // Обновляем только переданные поля
    tasks[taskIndex] = { ...tasks[taskIndex], ...req.body };
    
    res.json(tasks[taskIndex]);
});

/**
 * DELETE /api/tasks/:id
 * Удалить задание
 */
app.delete('/api/tasks/:id', authenticateToken, (req, res) => {
    const taskId = parseInt(req.params.id);
    tasks = tasks.filter(t => t.id !== taskId);
    res.json({ message: 'Задание удалено' });
});

// ==============================================
// Запуск сервера
// ==============================================
app.listen(PORT, () => {
    console.log('='.repeat(50));
    console.log('🚀 Сервер успешно запущен!');
    console.log('='.repeat(50));
    console.log(`📡 Адрес: http://localhost:${PORT}`);
    console.log('\n📝 Доступные роуты:');
    console.log('   POST   /api/auth/login     - вход в систему');
    console.log('   GET    /api/auth/check     - проверка токена');
    console.log('   GET    /api/tasks           - все задания');
    console.log('   GET    /api/tasks/my        - мои задания');
    console.log('   POST   /api/tasks           - создать задание');
    console.log('   PATCH  /api/tasks/:id       - обновить задание');
    console.log('   DELETE /api/tasks/:id       - удалить задание');
    console.log('\n👤 Тестовые пользователи:');
    console.log('   shopmanager / 123');
    console.log('   officemanager / 123');
    console.log('   hr / 123');
    console.log('='.repeat(50));
});