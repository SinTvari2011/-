// Данные пользователей
const USERS = [
    { id: 1, login: 'shopmanager', password: '123', role: 'shopmanager', name: 'Иван Петров (Магазин)' },
    { id: 2, login: 'officemanager', password: '123', role: 'officemanager', name: 'Петр Сидоров (Офис)' },
    { id: 3, login: 'hr', password: '123', role: 'hr', name: 'Елена Смирнова (HR)' }
];

// Тестовые задания
let TASKS = [
    { 
        id: 1, 
        title: 'Установка оборудования', 
        description: 'Установить кассовое оборудование в магазине',
        startDate: '2026-04-10', 
        endDate: '2026-04-12', 
        status: 'cancelled', 
        createdBy: 1,
        createdByName: 'Иван Петров',
        requiredRoles: ['техник'], 
        assigned: [] 
    },
    { 
        id: 2, 
        title: 'Техническая проверка', 
        description: 'Проверить работу инженерных систем',
        startDate: '2026-06-20', 
        endDate: '2026-06-27', 
        status: 'in-progress', 
        createdBy: 1,
        createdByName: 'Иван Петров',
        requiredRoles: ['электрик', 'сантехник'], 
        assigned: ['Гзорян'] 
    },
    { 
        id: 3, 
        title: 'Устранение неисправностей', 
        description: 'Починить систему вентиляции',
        startDate: '2026-05-01', 
        endDate: '2026-05-10', 
        status: 'in-progress', 
        createdBy: 2,
        createdByName: 'Петр Сидоров',
        requiredRoles: ['электрик', 'сантехник'], 
        assigned: [] 
    },
    { 
        id: 4, 
        title: 'Настройка кассы', 
        description: 'Настроить программное обеспечение',
        startDate: '2026-07-01', 
        endDate: '2026-07-05', 
        status: 'done', 
        createdBy: 2,
        createdByName: 'Петр Сидоров',
        requiredRoles: ['техник'], 
        assigned: ['Гзорян', 'Григорян'] 
    },
    { 
        id: 5, 
        title: 'Ремонт электрощитка', 
        description: 'Заменить автоматы',
        startDate: '2026-07-10', 
        endDate: '2026-07-15', 
        status: 'hr-request', 
        createdBy: 2,
        createdByName: 'Петр Сидоров',
        requiredRoles: ['монтажник', 'электрик'], 
        assigned: [],
        hrRequest: true 
    },
    { 
        id: 6, 
        title: 'Проверка счётчика', 
        description: 'Проверить показания',
        startDate: '2026-11-20', 
        endDate: '2026-11-23', 
        status: 'hr-request', 
        createdBy: 2,
        createdByName: 'Петр Сидоров',
        requiredRoles: ['электрик'], 
        assigned: [],
        hrRequest: true 
    }
];

// Текущий пользователь
let currentUser = null;

// Функция входа
function login() {
    const username = document.getElementById('username').value;
    const password = document.getElementById('password').value;
    
    const user = USERS.find(u => u.login === username && u.password === password);
    
    if (user) {
        currentUser = user;
        document.getElementById('loginForm').style.display = 'none';
        document.getElementById('mainApp').style.display = 'block';
        document.getElementById('userName').textContent = user.name;
        renderContent();
    } else {
        alert('Неверный логин или пароль');
    }
}

// Функция выхода
function logout() {
    currentUser = null;
    document.getElementById('loginForm').style.display = 'block';
    document.getElementById('mainApp').style.display = 'none';
    document.getElementById('username').value = 'shopmanager';
    document.getElementById('password').value = '123';
}

// Получить статус по-русски
function getStatusText(status) {
    const statuses = {
        'draft': 'Черновик',
        'in-progress': 'В работе',
        'done': 'Выполнено',
        'cancelled': 'Отменено',
        'hr-request': 'Запрос в HR'
    };
    return statuses[status] || status;
}

// Создать кнопку
function createButton(text, className, onClick) {
    const btn = document.createElement('button');
    btn.textContent = text;
    btn.className = className || '';
    btn.onclick = onClick;
    return btn;
}

// Отрисовка контента для управляющего магазином
function renderShopManager() {
    const content = document.getElementById('content');
    content.innerHTML = '';
    
    // Форма создания задания
    const createCard = document.createElement('div');
    createCard.className = 'card create-task';
    createCard.innerHTML = `
        <h3>Создать новое задание</h3>
        <input type="text" id="taskTitle" placeholder="Название задания">
        <textarea id="taskDesc" placeholder="Описание"></textarea>
        <input type="date" id="taskStart">
        <input type="date" id="taskEnd">
        <input type="text" id="taskRoles" placeholder="Требуемые роли (через запятую)">
        <button onclick="createTask()">Создать задание</button>
    `;
    content.appendChild(createCard);
    
    // Список заданий
    const tasksCard = document.createElement('div');
    tasksCard.className = 'card';
    tasksCard.innerHTML = '<h3>Мои задания</h3><div id="tasksList"></div>';
    content.appendChild(tasksCard);
    
    // Фильтруем задания текущего пользователя
    const myTasks = TASKS.filter(t => t.createdBy === currentUser.id);
    const tasksList = document.getElementById('tasksList');
    
    myTasks.forEach(task => {
        const taskEl = document.createElement('div');
        taskEl.className = `task ${task.status}`;
        
        taskEl.innerHTML = `
            <div class="task-header">
                <span class="task-title">${task.title}</span>
                <span class="task-status">${getStatusText(task.status)}</span>
            </div>
            <div class="task-desc">${task.description}</div>
            <div class="task-meta">
                <span>📅 ${task.startDate || 'нет'} — ${task.endDate || 'нет'}</span>
                <span>👥 Требуются: ${task.requiredRoles.join(', ')}</span>
                ${task.assigned.length ? `<span>✅ Назначены: ${task.assigned.join(', ')}</span>` : ''}
            </div>
            <div class="task-actions" id="actions-${task.id}"></div>
        `;
        
        tasksList.appendChild(taskEl);
        
        // Кнопки действий
        const actionsDiv = document.getElementById(`actions-${task.id}`);
        
        if (task.status === 'draft') {
            actionsDiv.appendChild(createButton('Начать работу', '', () => updateTaskStatus(task.id, 'in-progress')));
        }
        if (task.status === 'in-progress') {
            actionsDiv.appendChild(createButton('Завершить', '', () => updateTaskStatus(task.id, 'done')));
        }
        if (task.status !== 'done' && task.status !== 'cancelled') {
            actionsDiv.appendChild(createButton('Отменить', '', () => updateTaskStatus(task.id, 'cancelled')));
        }
    });
}

// Отрисовка для управляющего офисом
function renderOfficeManager() {
    const content = document.getElementById('content');
    content.innerHTML = '';
    
    const card = document.createElement('div');
    card.className = 'card';
    card.innerHTML = '<h3>Задания в работе</h3><div id="tasksList"></div>';
    content.appendChild(card);
    
    const inProgress = TASKS.filter(t => t.status === 'in-progress' || t.status === 'hr-request');
    const tasksList = document.getElementById('tasksList');
    
    inProgress.forEach(task => {
        const taskEl = document.createElement('div');
        taskEl.className = `task ${task.status}`;
        
        taskEl.innerHTML = `
            <div class="task-header">
                <span class="task-title">${task.title}</span>
                <span class="task-status">${getStatusText(task.status)}</span>
            </div>
            <div class="task-desc">${task.description}</div>
            <div class="task-meta">
                <span>📅 ${task.startDate || 'нет'} — ${task.endDate || 'нет'}</span>
                <span>👥 Требуются: ${task.requiredRoles.join(', ')}</span>
                <span>👤 Автор: ${task.createdByName}</span>
                ${task.assigned.length ? `<span>✅ Назначены: ${task.assigned.join(', ')}</span>` : ''}
            </div>
            <div class="task-actions" id="actions-${task.id}"></div>
        `;
        
        tasksList.appendChild(taskEl);
        
        const actionsDiv = document.getElementById(`actions-${task.id}`);
        
        if (task.status === 'in-progress') {
            actionsDiv.appendChild(createButton('Назначить сотрудников', '', () => assignWorkers(task.id)));
            actionsDiv.appendChild(createButton('Заявка в HR', '', () => sendToHR(task.id)));
        }
        if (task.status === 'hr-request') {
            actionsDiv.innerHTML = '<span style="color: #9b59b6;">⏳ Ожидает HR</span>';
        }
    });
}

// Отрисовка для HR
function renderHR() {
    const content = document.getElementById('content');
    content.innerHTML = '';
    
    const card = document.createElement('div');
    card.className = 'card';
    card.innerHTML = '<h3>Заявки на подбор персонала</h3><div id="tasksList"></div>';
    content.appendChild(card);
    
    const hrRequests = TASKS.filter(t => t.hrRequest === true || t.status === 'hr-request');
    const tasksList = document.getElementById('tasksList');
    
    hrRequests.forEach(task => {
        const taskEl = document.createElement('div');
        taskEl.className = 'task hr';
        
        taskEl.innerHTML = `
            <div class="task-header">
                <span class="task-title">${task.title}</span>
                <span class="task-status">Запрос в HR</span>
            </div>
            <div class="task-desc">${task.description}</div>
            <div class="task-meta">
                <span>📅 Срок: до ${task.endDate || 'не указан'}</span>
                <span>👥 Нужны: ${task.requiredRoles.join(', ')}</span>
                <span>👤 Автор: ${task.createdByName}</span>
            </div>
            <div class="task-actions" id="actions-${task.id}"></div>
        `;
        
        tasksList.appendChild(taskEl);
        
        const actionsDiv = document.getElementById(`actions-${task.id}`);
        actionsDiv.appendChild(createButton('Назначить сотрудников', '', () => hireWorkers(task.id)));
    });
}

// Главная функция отрисовки
function renderContent() {
    if (!currentUser) return;
    
    if (currentUser.role === 'shopmanager') {
        renderShopManager();
    } else if (currentUser.role === 'officemanager') {
        renderOfficeManager();
    } else if (currentUser.role === 'hr') {
        renderHR();
    }
}

// Создать задание
function createTask() {
    const title = document.getElementById('taskTitle')?.value;
    const desc = document.getElementById('taskDesc')?.value;
    const start = document.getElementById('taskStart')?.value;
    const end = document.getElementById('taskEnd')?.value;
    const rolesInput = document.getElementById('taskRoles')?.value;
    
    if (!title) {
        alert('Введите название задания');
        return;
    }
    
    const roles = rolesInput ? rolesInput.split(',').map(r => r.trim()) : [];
    
    const newTask = {
        id: Date.now(),
        title: title,
        description: desc || '',
        startDate: start || '',
        endDate: end || '',
        status: 'draft',
        createdBy: currentUser.id,
        createdByName: currentUser.name,
        requiredRoles: roles,
        assigned: []
    };
    
    TASKS.push(newTask);
    renderContent();
}

// Обновить статус задания
function updateTaskStatus(taskId, newStatus) {
    const task = TASKS.find(t => t.id === taskId);
    if (task) {
        task.status = newStatus;
        renderContent();
    }
}

// Назначить сотрудников
function assignWorkers(taskId) {
    const workers = prompt('Введите имена сотрудников через запятую:', 'Иванов, Петров, Сидоров');
    if (workers) {
        const task = TASKS.find(t => t.id === taskId);
        if (task) {
            task.assigned = workers.split(',').map(w => w.trim());
            renderContent();
        }
    }
}

// Отправить заявку в HR
function sendToHR(taskId) {
    const task = TASKS.find(t => t.id === taskId);
    if (task) {
        task.status = 'hr-request';
        task.hrRequest = true;
        renderContent();
    }
}

// HR назначает сотрудников
function hireWorkers(taskId) {
    const workers = prompt('Введите имена подобранных сотрудников:', 'Смирнова, Кузнецов, Попова');
    if (workers) {
        const task = TASKS.find(t => t.id === taskId);
        if (task) {
            task.assigned = workers.split(',').map(w => w.trim());
            task.status = 'in-progress';
            task.hrRequest = false;
            renderContent();
        }
    }
}